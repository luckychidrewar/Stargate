package com.example.demo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import io.spring.guides.gs_producing_web_service.Customers;

@Component
public class CustomersRepository {
	
	private static final Map<Integer,Customers> customers = new HashMap<Integer,Customers>();
	
	@PostConstruct
	public void initData(){
		Customers customer1 = new Customers();
		customer1.setId(1);
		customer1.setName("Laximikant");
		customer1.setMobileNo("9876543211");
		customer1.setAccountNumber(11111);
		
		customers.put(1, customer1);
	
		Customers customer2 = new Customers();
		customer2.setId(2);
		customer2.setName("Suraj");
		customer2.setMobileNo("9876543212");
		customer2.setAccountNumber(22222);
		
		customers.put(2, customer2);
		
	}
		
	@SuppressWarnings("null")
	public List<Customers> getAllCustomers() {
		
		List<Customers> customerList = new ArrayList<>();
		Set<Integer> customerKeySet = customers.keySet();
		
		for (Integer integer : customerKeySet) {
			customerList.add(customers.get(integer));
		}
		
		return customerList;
	}
}
