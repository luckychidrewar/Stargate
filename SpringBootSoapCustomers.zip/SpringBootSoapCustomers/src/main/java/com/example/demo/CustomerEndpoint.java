package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import io.spring.guides.gs_producing_web_service.GetAllCustomersResponse;

@Endpoint
public class CustomerEndpoint {

	private static final String NAMESPACE_URI = "http://spring.io/guides/gs-producing-web-service";
	
	
	private CustomersRepository customersRepository;
	
	@Autowired
	public CustomerEndpoint(CustomersRepository customersRepository) {
		this.customersRepository = customersRepository;
	}
	
	@PayloadRoot(namespace = NAMESPACE_URI, localPart="getAllCustomersRequest")
	@ResponsePayload
	public GetAllCustomersResponse getAllCustomers(){
		GetAllCustomersResponse response = new GetAllCustomersResponse();
		response.getCustomer().addAll(customersRepository.getAllCustomers());
		
		return response;
	}
	
}
