package loanpaymentdetails;

import java.util.regex.Pattern;

import org.mule.api.MuleEvent;
import org.mule.extension.validation.api.ValidationResult;
import org.mule.extension.validation.api.Validator;
import org.mule.extension.validation.internal.ImmutableValidationResult;
import org.mule.module.http.internal.ParameterMap;

public class CustomValidator implements Validator {

	@Override
	public ValidationResult validate(MuleEvent event) {
		ParameterMap pm =  event.getMessage().getInboundProperty("http.uri.params");
		String accountId = pm.get("accountId");
		
		final Pattern pattern = Pattern.compile("\\d++");
		if (accountId != null && accountId.length() <= 128 && pattern.matcher(accountId).matches()) 
	   	{ 
			return ImmutableValidationResult.ok();
	   	} 
		else
		{
			return ImmutableValidationResult.error("Bad Request");
		}
		
	}

}
