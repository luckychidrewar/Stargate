package loanpaymentdetails;
import java.io.File;
import java.io.FileOutputStream;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;
import org.mule.api.MuleEventContext;
import org.mule.api.MuleMessage;
import org.mule.api.lifecycle.Callable;

import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.draw.VerticalPositionMark;

public class PDFUtility implements Callable{

	 private static final String FILE_NAME = "d:/itext.pdf";
	 private static Font catFont = new Font(Font.FontFamily.TIMES_ROMAN, 18, Font.BOLD);
	 private static Font subFont = new Font(Font.FontFamily.TIMES_ROMAN, 4, Font.BOLD);
	 
	@Override
	public Object onCall(MuleEventContext eventContext) throws Exception {
		MuleMessage message = eventContext.getMessage();
		System.out.println("java class: "+ message.getPayloadAsString());
		String response = message.getPayloadAsString();
		
		JSONArray jArray = new JSONArray(response);
		System.out.println("response-------->"+response);
		/*JSONObject jsonobjectHeader = jArray.getJSONObject(0);*/
		/*String bankName = jsonobjectHeader.getString("name");
		String customerPreFix = jsonobjectHeader.getString("Prefix");
		String customerFirstName = jsonobjectHeader.getString("First");
		String customerLastName = jsonobjectHeader.getString("Last");
		String customerAddressLine1 = jsonobjectHeader.getString("Line1");
		String customerAddressLine2 = jsonobjectHeader.getString("Line2");
		String customerCity = jsonobjectHeader.getString("City");
		String customerState = jsonobjectHeader.getString("State");
		String customerZip = jsonobjectHeader.getString("Zip");
		String customerCountry = jsonobjectHeader.getString("Country");
		String customerId = jsonobjectHeader.getString("customerId");
		String currency = jsonobjectHeader.getString("Currency");
		String accountNumber = jsonobjectHeader.getString("AccountNumber");*/
		System.out.println("----------------------Statement Header-------------------------");
		
		// writing content into PDF file
		Document document = new Document();
		PdfWriter.getInstance(document, new FileOutputStream(new File(FILE_NAME)));
		document.open();
		/* Paragraph preface1 = new Paragraph();
		 preface1.add("Bank ");
		 preface1.add(bankName);
		 preface1.setAlignment(Element.ALIGN_CENTER);
         document.add(preface1);
         
         Chunk glue = new Chunk(new VerticalPositionMark());
         Paragraph preface2 = new Paragraph();
         addEmptyLine(preface2, 3);
         preface2.add("Customer Name:  ");
         preface2.add(customerPreFix +" "+ customerFirstName +" " + customerLastName);
         preface2.add("\n");
         preface2.add("Address:  ");
         preface2.add(customerAddressLine1 +" "+ customerAddressLine2);
         preface2.add("\n");
         preface2.add(customerCity +" "+ customerState +" "+customerZip +" "+customerCountry);
         preface2.add("\n");
         preface2.add("Account Number:  ");
         preface2.add(accountNumber);
         preface2.add(new Chunk(glue));
         preface2.add("Customer Id:  ");
         preface2.add(customerId);
         document.add(preface2);
         
         Paragraph preface3 = new Paragraph();
         preface3.add("Currency: ");
         preface3.add(currency);
         preface3.setFont(subFont);
         preface3.setAlignment(Element.ALIGN_RIGHT);
         addEmptyLine(preface3, 2);
         document.add(preface3);*/
         
         // Adding Table
         PdfPTable table = new PdfPTable(5);
         PdfPCell c1 = new PdfPCell(new Phrase("EscrowAmount"));
         c1.setHorizontalAlignment(Element.ALIGN_CENTER);
         table.addCell(c1);
         
         c1 = new PdfPCell(new Phrase("InterestAmount"));
         c1.setHorizontalAlignment(Element.ALIGN_CENTER);
         table.addCell(c1);
         
         c1 = new PdfPCell(new Phrase("PrincipalAmount"));
         c1.setHorizontalAlignment(Element.ALIGN_CENTER);
         table.addCell(c1);
         
         c1 = new PdfPCell(new Phrase("FeesAmount"));
         c1.setHorizontalAlignment(Element.ALIGN_CENTER);
         table.addCell(c1);
         
         c1 = new PdfPCell(new Phrase("InsuranceAmount"));
         c1.setHorizontalAlignment(Element.ALIGN_CENTER);
         table.addCell(c1);
         
         c1 = new PdfPCell(new Phrase("PmiAmount"));
         c1.setHorizontalAlignment(Element.ALIGN_CENTER);
         table.addCell(c1);
         
         table.setHeaderRows(1);
         	
		System.out.println("----------------------Statement Details-------------------------");
		for (int i = 0; i < jArray.length(); i++) {
		    JSONObject jsonobject = jArray.getJSONObject(i);
		    String escrowAmount = jsonobject.getString("EscrowAmount");
		    String interestAmount = jsonobject.getString("InterestAmount");
		    String principalAmount = jsonobject.getString("PrincipalAmount");
		    String feesAmount = jsonobject.getString("FeesAmount");
		    String insuranceAmount = jsonobject.getString("InsuranceAmount");
		    String pmiAmount = jsonobject.getString("PmiAmount");
		    table.addCell(escrowAmount);
		    table.addCell(interestAmount);
		    table.addCell(principalAmount);
		    table.addCell(feesAmount);
		    table.addCell(insuranceAmount);
		    table.addCell(pmiAmount);
		    
		}
		document.add(table);
		document.close();

		
		return null;
	}
	
	private static void addEmptyLine(Paragraph paragraph, int number) {
        for (int i = 0; i < number; i++) {
            paragraph.add(new Paragraph(" "));
        }
    }

}
