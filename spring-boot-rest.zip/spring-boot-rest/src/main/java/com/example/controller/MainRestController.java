package com.example.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.dao.EmployeeDao;
import com.example.model.Employee;

@RestController
public class MainRestController {
	
	@Autowired
	private EmployeeDao employeeDao;
	
	@RequestMapping("/")
	@ResponseBody
	public String welcome(){
		return "Welcome to Rest example using spring boot";
	}
	
	@GetMapping(value="employee/{empNo}",produces="application/json")
	public ResponseEntity<Employee> getEmployee(@PathVariable("empNo") String empNo){
		return new ResponseEntity<Employee>(employeeDao.getEmployee(empNo),HttpStatus.OK);
	}
	
	@GetMapping(value="/employees",produces="application/json")
	public ResponseEntity<List<Employee>> getEmployees(){
		List<Employee> employeeList = employeeDao.getAllEmployees();
		return new ResponseEntity<>(employeeList,HttpStatus.OK);
	}
	
	@PostMapping(value="/employee",produces="application/json")
	public ResponseEntity<Employee> addEmployee(@Valid @RequestBody Employee employee){
		System.out.println("Added Employee"+employee.getEmpNo());
		return new ResponseEntity<>(employeeDao.addEmployee(employee),HttpStatus.OK);
	}
	
	@PutMapping(value="/employee",produces="application/json")
	public ResponseEntity<Employee> updateEmployee(@RequestBody Employee employee){
		System.out.println("Updated Employee"+employee.getEmpNo());
		return new ResponseEntity<Employee>(employeeDao.updateEmployee(employee),HttpStatus.OK);
	}

	@DeleteMapping(value="employee/{empNo}")
	public ResponseEntity<String> deleteEmployee(@PathVariable("empNo") String empNo){
		System.out.println("deleting employee"+empNo);
		return new ResponseEntity<String>(employeeDao.deleteEmployee(empNo), HttpStatus.OK);
	}
	
}
