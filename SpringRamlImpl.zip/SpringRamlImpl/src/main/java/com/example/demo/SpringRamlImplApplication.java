package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.capgemini.stargate.controller.model.Customer;

@SpringBootApplication
public class SpringRamlImplApplication {

	public static void main(String[] args) {
		
		Customer customer = new Customer();
		
		SpringApplication.run(SpringRamlImplApplication.class, args);
	}
}
