package com.example.demo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class AccountRepository {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public List<Account> findAll(){
		return jdbcTemplate.query("select * from Account", new AccountRowMapper());
	}

	class AccountRowMapper implements RowMapper<Account>
	{

		@Override
		public Account mapRow(ResultSet rs, int rowNum) throws SQLException {

			Account account = new Account();
			account.setAccountDescriptorId(rs.getInt("AccountDescriptorId"));
			account.setParentAccountId(rs.getInt("ParentAccountId"));
			account.setNickName(rs.getString("Nickname"));
			account.setCurrency(rs.getString("Currency"));
			account.setAccountNumber(rs.getString("AccountNumber"));
			account.setInterestRate(rs.getString("InterestRate"));
			
			return account;
		}
		
	}
	
}
