package com.example.demo;

import javax.persistence.Entity;

@Entity
public class Account {
	
	private int accountDescriptorId;
	
	private int parentAccountId;
	
	private String nickName;
	
	private String currency;
	
	private String accountNumber;
	
	private String interestRate;

	public int getAccountDescriptorId() {
		return accountDescriptorId;
	}

	public void setAccountDescriptorId(int accountDescriptorId) {
		this.accountDescriptorId = accountDescriptorId;
	}

	public int getParentAccountId() {
		return parentAccountId;
	}

	public void setParentAccountId(int parentAccountId) {
		this.parentAccountId = parentAccountId;
	}

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(String interestRate) {
		this.interestRate = interestRate;
	}
	
	
	
}
